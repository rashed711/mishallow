import React from 'react';
import { motion } from 'framer-motion';
import SEO from '../components/SEO';
import TeamSection from '../components/TeamSection';

const AboutPage: React.FC = () => {
    return (
        <div className="bg-white">
            <SEO
                title="من نحن | مكتب المحامي مشعل | نخبة محامين في مكة وجدة"
                description="تعرف على شركة المحامي مشعل بادغيش. نخبة من أفضل المحامين والمستشارين في مكة وجدة لتقديم استشارات قانونية وتمثيل قضائي احترافي للأفراد والشركات."
                image="/images/logo/logo.webp"
                url="https://mishal-lawfirm.com/about"
            />
            {/* Dark Luxury Hero */}
            <div className="relative pt-32 pb-16 md:pt-48 md:pb-28 bg-[#0F172A] overflow-hidden">
                <div className="absolute inset-0 pointer-events-none">
                    <img
                        src="/images/about/about-hero-bg.webp"
                        alt="من نحن - شركة مشعل بادغيش للمحاماة"
                        className="w-full h-full object-cover opacity-20"
                        loading="eager"
                        fetchPriority="high"
                        decoding="async"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-[#0F172A]/80 to-[#0F172A]/90"></div>
                </div>
                <div className="absolute inset-0 opacity-10 pointer-events-none">
                    <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                        <pattern id="about-pattern" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
                            <path d="M50 0 L100 50 L50 100 L0 50 Z" fill="none" stroke="#B89544" strokeWidth="0.5" />
                        </pattern>
                        <rect width="100%" height="100%" fill="url(#about-pattern)" />
                    </svg>
                </div>
                <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 text-center relative z-10">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                    >
                        <span className="text-[#B89544] font-black tracking-[0.2em] uppercase text-[10px] md:text-xs mb-4 block">إرث من الثقة</span>
                        <h1 className="text-3xl md:text-6xl font-black text-white mb-6">من نحن</h1>
                        <div className="h-1.5 w-24 bg-gradient-to-r from-transparent via-[#B89544] to-transparent mx-auto rounded-full"></div>
                    </motion.div>
                </div>
            </div>

            <section className="section-padding bg-white">
                <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
                    <div className="grid lg:grid-cols-2 gap-12 md:gap-20 items-center">
                        <motion.div
                            className="order-2 lg:order-1 text-center lg:text-right"
                            initial={{ opacity: 0, x: -30 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.8 }}
                        >
                            <h2 className="text-2xl md:text-4xl font-black text-[#0F172A] mb-8 leading-tight">الريادة المهنية في <br /><span className="text-[#B89544]">الأنظمة السعودية الحديثة</span></h2>
                            <div className="space-y-6 text-slate-600 text-base md:text-lg leading-relaxed font-bold">
                                <p>شركة مشعل بادغيش للمحاماة والاستشارات القانونية هي بيت خبرة قانوني متخصص، تأسست لتواكب القفزات النوعية في المنظومة العدلية السعودية ضمن رؤية المملكة 2030.</p>
                                <p>نحن نتخصص في تقديم الحلول القانونية التي تتطلب فهماً عميقاً لنظام الشركات الجديد، نظام المعاملات المدنية، ونظام المحاكم التجارية، مع الالتزام الكامل بالتحول الرقمي القضائي عبر منصة "ناجز".</p>
                            </div>
                        </motion.div>
                        <motion.div
                            className="order-1 lg:order-2 relative"
                            initial={{ opacity: 0, scale: 0.9 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.8 }}
                        >
                            <div className="absolute -inset-4 bg-[#B89544]/10 rounded-[2.5rem] md:rounded-[3rem] blur-2xl"></div>
                            <img
                                src="/images/about/about-justice.webp"
                                alt="شركة مشعل بادغيش للمحاماة والاستشارات القانونية"
                                width={600}
                                height={400}
                                loading="lazy"
                                decoding="async"
                                className="relative z-10 rounded-[2rem] md:rounded-[2.5rem] shadow-2xl w-full"
                            />
                        </motion.div>
                    </div>
                </div>
            </section>

            {/* Stats Section */}
            <section className="section-padding bg-[#0F172A] text-white">
                <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                        {[
                            { title: "رؤيتنا", desc: "أن نكون القوة القانونية الدافعة لنجاح الأعمال وحماية الأفراد في المملكة، عبر تطبيق أدق معايير الحوكمة والامتثال القضائي." },
                            { title: "رسالتنا", desc: "توفير تمثيل قانوني رفيع المستوى يستند إلى الأنظمة الحديثة والسوابق القضائية، مع توظيف التقنية العدلية لخدمة موكلينا." },
                            { title: "قيمنا", desc: "الشفافية المطلقة، السرية المهنية الصارمة، والحلول الابتكارية التي تمنع النزاعات قبل وقوعها." }
                        ].map((item, idx) => (
                            <motion.div
                                key={idx}
                                className="bg-white/5 p-10 rounded-[2rem] border border-white/10 hover:border-[#B89544]/40 transition-all text-center group"
                                initial={{ opacity: 0, y: 30 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: idx * 0.2, duration: 0.6 }}
                                whileHover={{ y: -10 }}
                            >
                                <h3 className="text-2xl font-black text-[#B89544] mb-4">{item.title}</h3>
                                <p className="text-slate-300 leading-relaxed font-bold">{item.desc}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Team Section */}
            <TeamSection />
        </div>
    );
};

export default AboutPage;