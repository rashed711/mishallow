import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { NavLink, Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

interface HeaderProps {
  onOpenModal: () => void;
}

const Header: React.FC<HeaderProps> = ({ onOpenModal }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);

    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      window.removeEventListener('scroll', handleScroll);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleLogoClick = (e: React.MouseEvent) => {
    if (location.pathname === '/') {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      // If not on home page, Link will handle it (navigates to /)
      // but we could also close the mobile menu if it's open
      setIsOpen(false);
    }
  };

  const Logo: React.FC<{ light?: boolean }> = ({ light = true }) => (
    <Link
      to="/"
      onClick={handleLogoClick}
    className="flex items-center gap-4 focus:outline-none group"
      title="شركة مشعل بادغيش للمحاماة - الصفحة الرئيسية"
      aria-label="العودة إلى الصفحة الرئيسية لشركة مشعل بادغيش"
    >
      <div className="bg-white p-0 rounded-sm shadow-lg shadow-[#B89544]/20 transition-transform duration-300 group-hover:scale-105 flex items-center justify-center overflow-hidden">
        <img
          src="/images/logo/logo.webp"
          alt="شعار شركة مشعل بادغيش للمحاماة"
          width={60}
          height={60}
          loading="eager"
          fetchpriority="high"
          className="h-11 w-11 md:h-[60px] md:w-[60px] object-contain"
        />
      </div>
      <div className="flex flex-col items-start leading-none">
        <span className={`text-base md:text-xl font-black tracking-tight ${light ? 'text-white' : 'text-[#0F172A]'}`}>مشعل بادغيش</span>
        <span className="text-[7px] md:text-[9px] tracking-[0.15em] text-[#B89544] font-bold uppercase mt-1">للمحاماة والاستشارات</span>
      </div>
    </Link>
  );

  const navLinks = [
    { to: '/', text: 'الرئيسية', title: 'الانتقال إلى الصفحة الرئيسية' },
    { to: '/about', text: 'من نحن', title: 'تعرف على خبراتنا وفريقنا القانوني' },
    { to: '/services', text: 'خدماتنا', title: 'استكشف تخصصاتنا وخدماتنا القانونية' },
    { to: '/articles', text: 'المقالات', title: 'اقرأ آخر الرؤى والدراسات القانونية' },
  ];

  const closeMenu = () => setIsOpen(false);

  return (
    <header className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-500 h-16 md:h-24 ${scrolled
      ? 'bg-[#0F172A]/90 backdrop-blur-xl shadow-2xl border-b border-white/5'
      : 'bg-[#0F172A]/80 backdrop-blur-sm'
      }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 h-full">
        <div className="flex items-center justify-between h-full">
          <div className="flex-shrink-0">
            <Logo />
          </div>

          {/* Desktop Nav */}
          <nav className="hidden lg:block">
            <div className="flex items-center gap-x-10 xl:gap-x-20">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  title={link.title}
                  className={({ isActive }) => `text-sm font-bold transition-all relative py-2 group ${isActive ? 'text-[#B89544]' : 'text-slate-300 hover:text-white'}`}
                >
                  {({ isActive }) => (
                    <>
                      {link.text}
                      <span className={`absolute bottom-0 right-0 w-full h-0.5 bg-[#B89544] transform origin-right transition-transform duration-300 ${isActive ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></span>
                    </>
                  )}
                </NavLink>
              ))}
              <Link
                to="/contact"
                className="relative overflow-hidden bg-gradient-to-r from-[#B89544] to-[#D4AF37] text-[#0F172A] px-7 py-3 rounded-xl text-xs font-black hover:brightness-110 hover:-translate-y-0.5 transition-all shadow-lg active:scale-95 group"
              >
                <span className="relative z-10">تواصل معنا</span>
                <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:animate-shimmer" style={{ animationDuration: '2s' }}></span>
              </Link>
            </div>
          </nav>

          {/* Mobile Toggle */}
          <div className="flex lg:hidden">
            <button
              onClick={() => setIsOpen(true)}
              className="p-2.5 text-white bg-white/5 border border-white/10 rounded-xl active:scale-90 transition-transform"
              aria-label="فتح القائمة"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Advanced Drawer Mobile Menu - Animated */}
      {typeof document !== 'undefined' && createPortal(
        <AnimatePresence>
          {isOpen && (
            <div className="fixed inset-0 z-[9999] lg:hidden" dir="rtl">
              {/* Backdrop overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="absolute inset-0 bg-black/60 backdrop-blur-md"
                onClick={closeMenu}
              ></motion.div>

              {/* Sidebar Drawer */}
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="absolute top-0 right-0 w-[85%] max-w-[360px] h-full bg-[#0F172A] shadow-[0_0_50px_rgba(0,0,0,0.5)] border-l border-white/10 flex flex-col z-[10000]"
              >
                <div className="p-6 flex items-center justify-between border-b border-white/5 bg-white/2">
                  <Logo />
                  <button
                    onClick={closeMenu}
                    className="p-2 text-slate-400 hover:text-white bg-white/5 rounded-xl border border-white/10"
                  >
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>

                <nav className="flex-grow py-8 px-4 overflow-y-auto">
                  <div className="space-y-1">
                    {navLinks.map((link, idx) => (
                      <motion.div
                        key={link.to}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.1 + idx * 0.1, duration: 0.4 }}
                      >
                        <NavLink
                          to={link.to}
                          onClick={closeMenu}
                          className={({ isActive }) => `flex items-center px-6 py-4.5 rounded-2xl text-[17px] font-bold transition-all duration-300 ${isActive ? 'bg-[#B89544] text-[#0F172A] shadow-lg shadow-[#B89544]/20' : 'text-slate-300 hover:bg-white/5 hover:text-white'
                            }`}
                        >
                          {link.text}
                        </NavLink>
                      </motion.div>
                    ))}
                  </div>
                </nav>

                <div className="p-6 border-t border-white/5 bg-white/2 pb-10">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4, duration: 0.5 }}
                  >
                    <Link
                      to="/contact"
                      onClick={closeMenu}
                      className="w-full block bg-gradient-to-r from-[#B89544] to-[#D4AF37] text-[#0F172A] py-5 rounded-2xl font-black text-center shadow-xl mb-6 active:scale-95 transition-all"
                    >
                      تواصل معنا
                    </Link>
                  </motion.div>
                  <div className="flex justify-center space-x-6 rtl:space-x-reverse opacity-40">
                    <span className="text-[10px] font-black tracking-widest text-[#B89544] uppercase">شركة مشعل بادغيش للمحاماة</span>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>,
        document.body
      )}
    </header>
  );
};

export default React.memo(Header);

