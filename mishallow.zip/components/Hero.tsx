import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const backgroundImages = [
  "/images/hero/hero-1.webp",
  "/images/hero/hero-2.webp",
  "/images/hero/hero-3.webp",
  "/images/hero/hero-4.webp"
];

const Hero: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % backgroundImages.length);
    }, 8000);
    return () => {
      clearInterval(timer);
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden bg-[#0F172A]">

      {/* Cinematic Background Slider */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode='wait'>
          <motion.div
            key={currentIndex}
            initial={currentIndex === 0 ? { opacity: 1 } : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: isMobile ? 0.5 : 1.2 }}
            className="absolute inset-0"
          >
            <img
              src={backgroundImages[currentIndex]}
              sizes="(max-width: 768px) 100vw, 1600px"
              alt="المحامي مشعل بادغيش - خبير قانوني في مكة وجدة"
              width={1600}
              height={900}
              fetchpriority={currentIndex === 0 ? "high" : "auto"}
              className="w-full h-full object-cover brightness-[0.8] contrast-[1.1]"
              loading={currentIndex === 0 ? "eager" : "lazy"}
              decoding={currentIndex === 0 ? "sync" : "async"}
            />
          </motion.div>
        </AnimatePresence>

        <div className="absolute inset-0 bg-gradient-to-l from-[#0F172A] via-[#0F172A]/85 to-transparent z-[1]"></div>
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-[#0F172A] to-transparent z-[2]"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 relative z-10 w-full pt-32 lg:pt-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">

          <div className="lg:col-span-7 text-center lg:text-right">
            <motion.div
              variants={{
                hidden: { opacity: 0 },
                visible: {
                  opacity: 1,
                  transition: {
                    staggerChildren: 0.12,
                    delayChildren: 0.1
                  }
                }
              }}
              initial="hidden"
              animate="visible"
            >
              <motion.div
                variants={{
                  hidden: { opacity: 0, y: 30, scale: 0.9 },
                  visible: { 
                    opacity: 1, 
                    y: 0, 
                    scale: 1,
                    transition: { type: "spring", stiffness: 120, damping: 14 } 
                  }
                }}
                className="inline-flex items-center px-4 py-2 bg-[#B89544]/20 border border-[#B89544]/40 backdrop-blur-sm text-[#F3E2B1] rounded-full text-[10px] md:text-xs font-black tracking-widest uppercase mb-8 shadow-lg"
              >
                <span className="w-2 h-2 bg-[#B89544] rounded-full ml-3 shadow-[0_0_10px_#B89544]"></span>
                شركة مشعل بادغيش للمحاماة والاستشارات القانونية
              </motion.div>

              <h1 className="mb-8">
                <div className="overflow-hidden mb-2">
                  <motion.span
                    variants={{
                      hidden: { opacity: 0, y: 70 },
                      visible: { 
                        opacity: 1, 
                        y: 0, 
                        transition: { type: "spring", stiffness: 100, damping: 12 } 
                      }
                    }}
                    className="fluid-h1 font-black text-white leading-tight drop-shadow-xl block"
                  >
                    شركة محاماة خبيرة
                  </motion.span>
                </div>
                <div className="overflow-hidden">
                  <motion.span
                    variants={{
                      hidden: { opacity: 0, y: 70 },
                      visible: { 
                        opacity: 1, 
                        y: 0, 
                        transition: { type: "spring", stiffness: 100, damping: 12, delay: 0.1 } 
                      }
                    }}
                    className="fluid-h1 font-black text-transparent bg-clip-text bg-gradient-to-l from-[#B89544] via-[#F3E2B1] to-[#D4AF37] leading-tight pb-2 block"
                  >
                    بأنظمة المملكة الحديثة في مكة
                  </motion.span>
                </div>
              </h1>

              <motion.p
                variants={{
                  hidden: { opacity: 0, y: 30 },
                  visible: { 
                    opacity: 1, 
                    y: 0, 
                    transition: { type: "spring", stiffness: 90, damping: 15 } 
                  }
                }}
                className="text-white text-base md:text-lg leading-relaxed font-bold mb-10 max-w-2xl mx-auto lg:mx-0 drop-shadow-lg opacity-90"
              >
                نقدم خدمات قانونية تخصصية في مكة وجدة، تركز على نظام الشركات الجديد، نظام المعاملات المدنية، والتمثيل القضائي عبر منصة "ناجز"، لضمان حماية استباقية لمصالح الأفراد والكيانات التجارية.
              </motion.p>

              <motion.div
                variants={{
                  hidden: { opacity: 0, y: 30 },
                  visible: { 
                    opacity: 1, 
                    y: 0, 
                    transition: { type: "spring", stiffness: 100, damping: 12 } 
                  }
                }}
                className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-5 md:gap-8"
              >
                <div className="animate-luxury-float w-full sm:w-auto">
                  <Link to="/contact" className="relative group block">
                    <button className="w-full relative z-10 bg-gradient-to-r from-[#B89544] via-[#D4AF37] to-[#B89544] text-[#0F172A] font-black px-10 py-6 md:py-7 rounded-2xl bg-[length:200%_auto] animate-luxury-pulse animate-gradient-move overflow-hidden shadow-[0_0_20px_rgba(184,149,68,0.6)] hover:shadow-[0_0_30px_rgba(184,149,68,0.95)] transition-all duration-300">
                      {/* Permanent Shimmer Sweep */}
                      <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full animate-luxury-shimmer pointer-events-none"></span>
                      <span className="relative z-10 text-base md:text-lg">
                        استشارة قانونية مجانية
                      </span>
                    </button>
                  </Link>
                </div>

                <div className="animate-luxury-float w-full sm:w-auto" style={{ animationDelay: '0.5s' }}>
                  <Link to="/services" className="relative group block">
                    <button className="w-full relative z-10 bg-white/10 backdrop-blur-md border border-white/20 text-white font-black px-10 py-6 md:py-7 rounded-2xl transition-all hover:bg-white/15 hover:border-[#B89544]/50 group-hover:shadow-[0_0_20px_rgba(255,255,255,0.1)] overflow-hidden group">
                      {/* Subtle Shimmer for the secondary button */}
                      <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-luxury-shimmer pointer-events-none"></span>
                      <span className="text-base md:text-lg group-hover:text-[#F3E2B1] transition-colors">استكشف خدماتنا</span>
                    </button>
                  </Link>
                </div>
              </motion.div>
            </motion.div>
          </div>

          {/* Stats Cards - Simplified blurs for mobile */}
          <motion.div
            className="lg:col-span-5 relative mt-6 lg:mt-0"
            initial={{ opacity: 0, x: 50, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ type: "spring", stiffness: 80, damping: 12, delay: 0.4 }}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4 md:gap-6">
              <motion.div 
                whileHover={{ scale: 1.05, y: -4 }}
                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                className="bg-white/5 backdrop-blur-sm p-6 rounded-3xl border border-white/10 group transition-all hover:bg-white/10 cursor-default"
              >
                <div className="flex items-center gap-5">
                  <div className="bg-[#B89544] p-3 rounded-2xl shadow-xl flex-shrink-0">
                    <svg className="w-6 h-6 text-[#0F172A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-white text-2xl font-black">10+</div>
                    <div className="text-[#B89544] font-bold text-xs uppercase">أعوام من التميز</div>
                  </div>
                </div>
              </motion.div>

              <motion.div 
                whileHover={{ scale: 1.05, y: -4 }}
                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                className="bg-white/5 backdrop-blur-sm p-6 rounded-3xl border border-white/10 group transition-all hover:bg-white/10 cursor-default"
              >
                <div className="flex items-center gap-5">
                  <div className="bg-white/10 p-3 rounded-2xl border border-white/20 flex-shrink-0">
                    <svg className="w-6 h-6 text-[#B89544]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-white text-2xl font-black">98%</div>
                    <div className="text-slate-300 font-bold text-xs uppercase">نسبة الإنجاز</div>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Slider indicators */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 flex gap-4">
        {backgroundImages.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentIndex(idx)}
            className={`relative before:absolute before:-inset-6 before:content-[''] h-1 rounded-full transition-all duration-500 ${idx === currentIndex ? 'w-10 bg-[#B89544]' : 'w-2 bg-white/20'}`}
            aria-label={`الذهاب إلى الصورة رقم ${idx + 1}`}
          />
        ))}
      </div>
    </section >
  );
};

export default Hero;